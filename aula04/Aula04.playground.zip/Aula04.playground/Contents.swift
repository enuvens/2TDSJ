//: Playground - noun: a place where people can play

import Foundation

/*
//Enumeradores (Enumeration): enum
enum Compass{
    case north
    case south
    case east
    case west
}

var heading: Compass = .south

//Switch
switch heading {
case .north:
    print("Usuário indo para o norte")
case .south:
    print("Usuário indo para o sul")
default:
   print("Indo em outra direção")
}

var speed: Double = 120.0

switch speed {
case 0.0..<40.0:
    print("Está na primeira marcha")
case 40.0..<60.0:
    print("Está na segunda marcha")
case 60.0..<90.0:
    print("Está na terceira marcha")
case 90..<110.0:
    print("Está na quarta marcha")
default:
    print("Está no inferno")
}

var letter: String = "m";

switch letter {
case "a"..."m":
    print("A letra \(letter) está na primeira metade")
default:
    print("A letra \(letter) está na segunda metade")
}

enum WeekDay: String{
    case sunday = "domingo"
    case monday = "segunda"
    case tuesday = "terça"
    case wednesday = "quarta"
    case thursday = "quinta"
}

var today: WeekDay = .thursday

print("Hoje é \(today.rawValue)")

enum Measure {
    case age(Int)
    case weight(Double)
    case size(width: Double, height: Double)
}

let measure: Measure = .size(width: 30.0, height: 50.0)

switch measure {
case .age(let age):
    print("A idade é \(age)")
case .weight(let weight):
    print("O peso é \(weight)")
case .size(let size):
    print("O tamanho é \(size.width) x \(size.height)")
}

//Structs
/*
 Maneiras de criar seu proprio tipo
 */
struct Driver{
    var name: String
    var registration: String
    var age: Int
}

var driver: Driver = Driver(name: "Raul", registration: "Tx45878321", age: 20)
print(driver.name)

var driver2: Driver = driver
driver.name = "Jaber"

print(driver2.name)
print(driver.name)

//Funções
func sayHello(to name: String, b: String){
    print("Olá \(name) e \(b)")
}

sayHello(to: "Raul", b: "João")

/*
 Usando o _ não precisa passar o nome da variavel da função
*/
func registerDriver(_ driver: Driver){
    //
}
registerDriver(driver)

func calcNumbers(_ a: Int, _ b: Int) -> Int {
    return a + b
}

calcNumbers(10, 12)


func combine(initialValue: Int, with values: Int...) -> Int {
    var result = initialValue
    
    for value in values {
        result += value
    }
    
    return result
}

combine(initialValue: 10, with: 2,5,7,8,21, 2)*/

func sum (a: Int, b: Int) -> Int{
    return a + b
}
func divide (a: Int, b: Int) -> Int{
    return a / b
}
func multiply (a: Int, b: Int) -> Int{
    return a * b
}
func subtract (a: Int, b: Int) -> Int{
    return a - b
}

func getOperation(named: String) -> (Int, Int) -> Int {
    switch named {
    case "sum":
        return sum
    case "divide":
        return divide
    case "multiply":
        return multiply
    default:
        return subtract
    }
}

var operation = getOperation(named: "multiply")
operation(1,2)
