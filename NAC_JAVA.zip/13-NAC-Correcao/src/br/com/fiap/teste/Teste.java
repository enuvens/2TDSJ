package br.com.fiap.teste;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import br.com.fiap.bean.Autor;
import br.com.fiap.bean.Editora;
import br.com.fiap.bean.Livro;
import br.com.fiap.nac.dao.LivroDAO;
import br.com.fiap.nac.dao.impl.LivroDAOImpl;
import br.com.fiap.nac.exception.DBException;
import br.com.fiap.nac.singleton.EntityManagerFactorySingleton;

public class Teste {

	public static void main(String[] args) {
		
		EntityManagerFactory fabrica = EntityManagerFactorySingleton.getInstance();
		EntityManager em = fabrica.createEntityManager();
		
		Editora editora = new Editora("Atlas", null);
		
		Autor autor = new Autor("Churros", Calendar.getInstance(), null);
		List<Autor> autores = new ArrayList<>();
		autores.add(autor);
		
		Livro livro = new Livro("123", "Java", null, editora, autores);
		
		LivroDAO dao = new LivroDAOImpl(em);
		
		try {
			dao.cadastrar(livro);
			dao.salvar();
		} catch (DBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		em.close();
		fabrica.close();
	}
	
	
	
	
}
