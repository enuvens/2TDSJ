package br.com.fiap.teste;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import br.com.fiap.bean.Livro;
import br.com.fiap.nac.dao.LivroDAO;
import br.com.fiap.nac.dao.impl.LivroDAOImpl;
import br.com.fiap.nac.singleton.EntityManagerFactorySingleton;

public class TesteBusca {

	public static void main(String[] args) {
		
		EntityManagerFactory fabrica = EntityManagerFactorySingleton.getInstance();
		EntityManager em = fabrica.createEntityManager();
		
		LivroDAO dao = new LivroDAOImpl(em);
		
		System.out.println("Busca por titulo");
		List<Livro> lista = dao.buscarPorTitulo("a");
		for (Livro livro : lista) {
			System.out.println(livro.getTitulo());
		}
		
		System.out.println("Quantidade de livros da Editora 1");
		System.out.println(dao.contarPorEditora(1));
		
		System.out.println("Busca de Livros pelo nome da editora");
		lista = dao.buscarPorNomeEditora("a");
		for (Livro livro : lista) {
			System.out.println(livro.getTitulo() +" - "+ livro.getEditora().getNome());
		}
		
		em.close();
		fabrica.close();
	}
	
	
	
	
}
