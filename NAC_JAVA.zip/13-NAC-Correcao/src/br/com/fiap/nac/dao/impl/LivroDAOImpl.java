package br.com.fiap.nac.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;

import br.com.fiap.bean.Livro;
import br.com.fiap.nac.dao.LivroDAO;

public class LivroDAOImpl 
	extends GenericDAOImpl<Livro, String>
		implements LivroDAO{

	public LivroDAOImpl(EntityManager em) {
		super(em);
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<Livro> buscarPorTitulo(String titulo) {
		
		return em.createQuery("from Livro l where l.titulo like :churros", Livro.class)
				.setParameter("churros", "%"+ titulo +"%")
				.setMaxResults(50)
				.getResultList();
		
	}

	@Override
	public long contarPorEditora(int codigo) {
		return em.createQuery("select count(l) from Livro l where l.editora.codigo = :churros", Long.class)
				.setParameter("churros", codigo)
				.getSingleResult();
	}

	@Override
	public List<Livro> buscarPorNomeEditora(String nomeEditora) {

		return em.createQuery("from Livro l where l.editora.nome like :churros", Livro.class)
				.setParameter("churros", "%"+ nomeEditora +"%")
				.getResultList();
		
	}

}
